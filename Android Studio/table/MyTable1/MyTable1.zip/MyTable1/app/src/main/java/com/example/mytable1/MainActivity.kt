package com.example.mytable1

import android.icu.text.DateFormat
import android.icu.text.SimpleDateFormat
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.mytable1.ui.theme.MyTable1Theme
import java.util.Date

val TAG = "MainActivity"
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.main);
        findViewById<Button>(R.id.add_an_item_button)
            .setOnClickListener {
                val simpleDateFormat = SimpleDateFormat()
                val input_raw_date = findViewById<EditText>(R.id.examination_date).getText().toString()
                val input_item = findViewById<EditText>(R.id.examination_item).getText().toString()
                val input_value = findViewById<EditText>(R.id.examination_value).getText().toString()


                if(input_raw_date.length == 6 && isInteger(input_raw_date) == true){
                    val input_parsed_date =  simpleDateFormat.parse(input_raw_date)
                    findViewById<TextView>(R.id.invalid_date_message).visibility = View.VISIBLE
                }else{
                    findViewById<TextView>(R.id.invalid_date_message).visibility = View.INVISIBLE
                }

                if(input_item.length != 0 ) {
                    Log.d(TAG, "input_item:" + input_item)
                    findViewById<TextView>(R.id.invalid_item_message).visibility = View.VISIBLE
                }else{
                    findViewById<TextView>(R.id.invalid_item_message).visibility = View.INVISIBLE
                }

                if(input_value.length != 0) {
                    Log.d(TAG, "input_value:" + input_value)
                    findViewById<TextView>(R.id.invalid_value_message).visibility = View.VISIBLE
                }else{
                    findViewById<TextView>(R.id.invalid_value_message).visibility = View.INVISIBLE
                }
            }
    }
}

fun isInteger(number : Any) : Boolean{
    val integerChars = '0'..'9'
    val s1 = number.toString()

    var i=0;
    for(i in 0..s1.length){
        val c = s1[i]
        if(c == null || c !in integerChars){
            return false
        }
    }
    return true
}